package mubs.edu.mobileapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;


/**
 * A simple {@link Fragment} subclass.
 */
public class MUBSFragment extends Fragment {
    WebView web;
    View view;

    public MUBSFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_m_u_b_s, container, false);
        web=view.findViewById(R.id.webview_mubs);
        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl("https://www.mubs.edu.lb/");
        return view;
    }
}
