package mubs.edu.mobileapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Lab1Ex1 extends AppCompatActivity {
	EditText txtTempValue;
	TextView txtres;
	RadioButton rbFtoC;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lab1_ex1);

		txtTempValue = findViewById(R.id.txtTempValue);
		rbFtoC = findViewById(R.id.rbFtoC);
		txtres = findViewById(R.id.txtConvertedValue);
	}

	public void ConvertNow(View view) {
		double val = Double.parseDouble(txtTempValue.getText().toString());
		double eqval = 0.;

		if (rbFtoC.isChecked()) {
			eqval = (val - 32) * 5 / 9;
		} else {
			eqval = val * 9 / 5 + 32;
		}
		txtres.setText(String.format("%.2f", eqval));
	}

	public static final int question2_ID = 101;
	public static final int question3_ID = 102;
	public static final int coffee_ID = 103;
	public static final int Quit_ID = 104;


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(1, question2_ID, 1, "Go to Question 2");
		menu.add(1, question3_ID, 2, "Go to Question 3");
		menu.add(1, coffee_ID, 3, "Coffee");
		menu.add(1, Quit_ID, 4, "Exit");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		switch (id) {
			case question2_ID:
				startActivity(new Intent(Lab1Ex1.this, Lab1Ex2.class));
				break;
			case question3_ID:
				startActivity(new Intent(Lab1Ex1.this, Lab1Ex3.class));
				break;
			case coffee_ID:
				startActivity(new Intent(Lab1Ex1.this, CoffeeRecommendation.class));
				break;
			case Quit_ID:
				AlertDialog.Builder alert = new AlertDialog.Builder(this);
				alert.setMessage("Do you want to Exit");
				alert.setTitle("Alert msg");
				alert.setIcon(R.drawable.mubs);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						finish();
						startActivity(new Intent(Lab1Ex1.this, MainActivity.class));
					}
				});
				alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						Toast.makeText(getApplicationContext(), "You choose to stay on the same app", Toast.LENGTH_LONG).show();
					}
				});
				alert.show();
				break;
			default:
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
