package mubs.edu.mobileapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CityManagementAdapter extends BaseAdapter {
	private Context gridContext;
	private CityManagementModel[] city;

	public CityManagementAdapter(Context gridContext, CityManagementModel[] city) {
		this.gridContext = gridContext;
		this.city = city;
	}

	@Override
	public int getCount() {
		return city.length;
	}

	@Override
	public Object getItem(int i) {
		return null;
	}

	@Override
	public long getItemId(int i) {
		return 0;
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		CityManagementModel c = city[i];
		if (view == null) {
			LayoutInflater inflater = LayoutInflater.from(gridContext);
			view = inflater.inflate(R.layout.city_management_view, null);
		}

		ImageView weatherImg = view.findViewById(R.id.item_gridview_wimg);
		TextView cityName = view.findViewById(R.id.item_gridview_cityname);
		TextView weather = view.findViewById(R.id.item_gridview_weather);
		TextView temp = view.findViewById(R.id.item_gridview_temp);

		weatherImg.setImageResource(c.getWeatherImg());
		cityName.setText(c.getCityName());
		weather.setText(c.getWeather());
		temp.setText(c.getTemp());

		LinearLayout layout = view.findViewById((R.id.item_layout_weather));
		layout.setBackgroundColor(c.getBackColor());

		return view;
	}
}
