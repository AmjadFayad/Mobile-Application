package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class Classwork15042020_2 extends AppCompatActivity {
    ListView lstFlags;
    ArrayList<HashMap<String,String>> data;
    int[] images=new int[]{R.drawable.lebanon,R.drawable.france,R.drawable.lebanon,
            R.drawable.lebanon,R.drawable.lebanon};
    String[] countname=new String[]{"Lebanon","France","USA","UK","Poland"};
    String[] phonecode=new String[]{"+961","+33","+1","+44","+48"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classwork15042020_2);
        lstFlags=findViewById(R.id.listflags);
        data=new ArrayList<>();
        HashMap<String,String> map=null;
        for(int i=0;i<images.length;i++) {
            map = new HashMap<String, String>();
            map.put("CountryFlag", String.valueOf(images[i]));
            map.put("CountryName", countname[i]);
            map.put("PhoneCode", phonecode[i]);
            data.add(map);
        }

        String[] from=new String[]{"CountryFlag","CountryName","PhoneCode"};
        int[] to =new int[]{R.id.sample_flagimg,R.id.sample_countryname,R.id.sample_phonecode};
        SimpleAdapter adapter=new SimpleAdapter(lstFlags.getContext(),
                data,R.layout.country_simple_row,from,to);
        lstFlags.setAdapter(adapter);
    }
}
