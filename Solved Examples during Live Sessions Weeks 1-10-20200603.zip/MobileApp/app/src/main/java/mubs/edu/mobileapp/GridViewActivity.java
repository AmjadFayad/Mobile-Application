package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

public class GridViewActivity extends AppCompatActivity {
	GridView gridView;
	Player[] players = new Player[3];

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_grid_view);

		gridView = findViewById(R.id.grid_view);
		players[0] = new Player(R.drawable.mubs, "MUBS");
		players[1] = new Player(R.drawable.bmi, "MBI");
		players[2] = new Player(R.drawable.coffee, "Coffee");

		CustomAdapter adapter = new CustomAdapter(gridView.getContext(), players);
		gridView.setAdapter(adapter);
	}
}
