package mubs.edu.mobileapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;

public class StudentDatabaseHelper extends SQLiteOpenHelper {
    public static String DatabaseName="StudentDb.db";
    public static int DataBaseVersion=1;
    public static String TableName="Student";

    public StudentDatabaseHelper(@Nullable Context context) {
        super(context, DatabaseName, null, DataBaseVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="CREATE TABLE "+TableName+" (StudentID INTEGER PRIMARY KEY," +
                " StudentName TEXT,Email TEXT,Password TEXT, Grade REAL)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldversion, int newversion) {
        String query="DROP TABLE IF EXISTS "+TableName;
        db.execSQL(query);
        onCreate(db);
    }

    public Boolean CheckStudent(int sid,String Pass) {
        String query = "Select * from " + TableName + " WHERE StudentID=? and Password=?";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cs = db.rawQuery(query, new String[]{String.valueOf(sid), Pass});
        // cs.getCount(); //will return the number of records returned by the sql query
        cs.moveToFirst();
        if (cs.getCount() > 0)
            return true;
        else return false;
    }
    public Boolean InsertNewStudent(int sid,String Sname,String Email,String Pass,float grade)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues vals=new ContentValues();
        vals.put("StudentID",sid);
        vals.put("StudentName",Sname);
        vals.put("Email",Email);
        vals.put("Password",Pass);
        vals.put("Grade",grade);
        long res=db.insert(TableName,null,vals);
        if(res>0)
            return true;
        else
            return false;
    }
    public Boolean UpdateStudentInfo(int sid,String Sname,String Email,String Pass,float grade)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues vals=new ContentValues();
        vals.put("StudentName",Sname);
        vals.put("Email",Email);
        vals.put("Password",Pass);
        vals.put("Grade",grade);
        int res= db.update(TableName,vals,"StudentID=?",new String[]{String.valueOf(sid)});
        if(res>0)
            return true;
        else
            return false;
    }
    public Boolean DeleteStudent(int sid) {
        SQLiteDatabase db=getWritableDatabase();
        int res=db.delete(TableName,"StudentID=?",new String[]{String.valueOf(sid)});
        if(res>0)
            return true;
        else
            return false;
    }
    public ArrayList<HashMap<String,String>> SelectAllStudents(){
        String query="Select StudentID, StudentName, Grade from "+TableName;
        SQLiteDatabase db=getReadableDatabase();
        Cursor cs=db.rawQuery(query,null);
        ArrayList<HashMap<String,String>> data=new ArrayList<>();
        while (cs.moveToNext()){
            HashMap<String,String> map=new HashMap<String, String>();
            map.put("SID", String.valueOf(cs.getInt(1)));
            map.put("SName",cs.getString(2));
            map.put("SGrade", String.valueOf(cs.getFloat(3)));
            data.add(map);
        }
        return data;
    }
}
