package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
	EditText txtusername, txtpassword;
	Button btnLogin;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);// assign the layout of the java class MainActivity

		// create a reference on the controls EditText username, password
		txtusername = findViewById(R.id.txtusername);
		txtpassword = findViewById(R.id.txtpassword);

		// create a reference for the Button btnLogin
		btnLogin = findViewById(R.id.btnLogin);

		// create a click listener on the Button btnLogin
		btnLogin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				// your code goes here
				Login_Clicked();
			}
		});
	}

	public void Login_Clicked() {
		String username = txtusername.getText().toString();
		String password = txtpassword.getText().toString();

		if (username.equals("omar") && password.equals("123456")) {
			Toast.makeText(this, "Welcome " + username, Toast.LENGTH_SHORT).show();
			startActivity(new Intent(MainActivity.this, CoffeeRecommendation.class));
		} else {
			Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
		}
	}
}
