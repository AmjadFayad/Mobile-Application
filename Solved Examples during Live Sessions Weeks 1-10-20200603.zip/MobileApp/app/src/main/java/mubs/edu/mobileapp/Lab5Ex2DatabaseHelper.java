package mubs.edu.mobileapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;

public class Lab5Ex2DatabaseHelper extends SQLiteOpenHelper {
    public static String DBname="PlacesDB.db";
    public static String TableName="Places";
    public Lab5Ex2DatabaseHelper(@Nullable Context context) {
        super(context, DBname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql="CREATE TABLE "+TableName+" (ID INTEGER PRIMARY KEY," +
                " place TEXT, country TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql="DROP TABLE IF EXISTS "+TableName;
        db.execSQL(sql);
        onCreate(db);
    }
    public ArrayList<HashMap<String,String>> getAllPlaces(){
        ArrayList<HashMap<String,String>> data=new ArrayList<>();
        String sql="SELECT * FROM "+TableName;
        SQLiteDatabase db=getReadableDatabase();
        Cursor cs=db.rawQuery(sql,null);
        while (cs.moveToNext()){
            HashMap<String,String> map=new HashMap<String, String>();
            map.put("PlaceID", String.valueOf(cs.getInt(0)));
            map.put("PlaceName",cs.getString(1));
            map.put("Country",cs.getString(2));
            data.add(map);
        }
        return data;
    }
    public long InsertNewPlace(int placeid,String placename,String Country)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues vals=new ContentValues();
        vals.put("ID",placeid);
        vals.put("place",placename);
        vals.put("country",Country);
        return db.insert(TableName,null,vals);
    }
    public int DeletePlace(int placeid)
    {
        SQLiteDatabase db=getWritableDatabase();
        return db.delete(TableName,"ID=?",new String[]{String.valueOf(placeid)});
    }
    public int UpdatePlace(int placeid,String placename,String Country)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues vals=new ContentValues();
        vals.put("place",placename);
        vals.put("country",Country);
       return db.update(TableName,vals,"ID=?",new String[]{String.valueOf(placeid)});
    }
}
