package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Lab5Ex2 extends AppCompatActivity {
    EditText txtPlaceID,txtPlaceName,txtCountry;
    TextView txtresult;
    Button btnAdd,btnUpdate,btnViewPlaces,btnDelete;
    Lab5Ex2DatabaseHelper helper=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab5_ex2);
        txtPlaceID=findViewById(R.id.edplaceid);
        txtPlaceName=findViewById(R.id.edplace);
        txtCountry=findViewById(R.id.edcountry);
        btnAdd=findViewById(R.id.btnadd);
        btnUpdate=findViewById(R.id.btnupdate);
        btnViewPlaces=findViewById(R.id.btnViewPlaces);
        btnDelete=findViewById(R.id.btnremove);
        txtresult=findViewById(R.id.lblResult);
        helper=new Lab5Ex2DatabaseHelper(this);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddNewPlace();
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RemovePlace();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UpdatePlace();
            }
        });
        btnViewPlaces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ViewAllPlaces();
            }
        });
    }
    private void AddNewPlace() {
        try {
           long res= helper.InsertNewPlace(Integer.parseInt(txtPlaceID.getText().toString()),
                    txtPlaceName.getText().toString(),txtCountry.getText().toString());
           if(res>0)
               txtresult.setText("Place added Successfully...");
           else
               txtresult.setText("Place not added");
        }catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void UpdatePlace() {
        int PID=Integer.parseInt(txtPlaceID.getText().toString());
        if(helper.UpdatePlace(PID,txtPlaceName.getText().toString(),
                txtCountry.getText().toString())>0)
            txtresult.setText("Place updated Successfully...");
        else
            txtresult.setText("Cannot update the place with ID: "+PID);
    }
    private void RemovePlace() {
        int PID=Integer.parseInt(txtPlaceID.getText().toString());
        if(helper.DeletePlace(PID)>0)
            txtresult.setText("Place deleted ...");
        else
            txtresult.setText("Cannot remove the place with ID: "+PID);
    }

    private void ViewAllPlaces() {
        Intent i =new Intent(Lab5Ex2.this,Lab5Ex2_ViewAll.class);
        startActivity(i);
    }
}
