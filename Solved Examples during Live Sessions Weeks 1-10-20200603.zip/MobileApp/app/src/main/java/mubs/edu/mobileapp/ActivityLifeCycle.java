package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class ActivityLifeCycle extends AppCompatActivity {
	LinearLayout layout;
	EditText txtColor;
	Button btnGo;
	public static String TAG = "myTAG";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_life_cycle);

		layout = findViewById(R.id.layout_ID);
		txtColor = findViewById(R.id.txtSelectedColor);
		btnGo = findViewById(R.id.btnGo);

		txtColor.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				try {
					String selectColor = txtColor.getText().toString();
					int colorCode = Color.parseColor(selectColor.toLowerCase());
					layout.setBackgroundColor(colorCode);
				} catch (Exception ex) {
					layout.setBackgroundColor(Color.WHITE);
				}
			}
		});

		btnGo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				ChangeBackColor();
			}
		});
		Log.i(TAG, "------------> On Create");
	}

	@Override
	protected void onStart() {
		super.onStart();
		Log.i(TAG, "------------> On Start");
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.i(TAG, "------------> On Resume");
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		Log.i(TAG, "------------> On Restart");
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.i(TAG, "------------> On Pause");
	}

	@Override
	protected void onStop() {
		super.onStop();
		Log.i(TAG, "------------> On Stop");
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "------------> On Destroy");
	}

	private void ChangeBackColor() {
		String selectColor = txtColor.getText().toString();
		int colorCode = Color.parseColor(selectColor.toLowerCase());
		layout.setBackgroundColor(colorCode);

//		if (selectColor.toLowerCase().equals("red"))
//			layout.setBackgroundColor(Color.RED);
//		else if (selectColor.toLowerCase().equals("green"))
//			layout.setBackgroundColor(Color.GREEN);
//		else if (selectColor.toLowerCase().equals("blue"))
//			layout.setBackgroundColor(Color.BLUE);
	}
}
