package mubs.edu.mobileapp;

public class CityManagementModel {
	private int weatherImg, backColor;
	private String cityName, weather, temp;

	public CityManagementModel(int weatherImg, String cityName, String weather, String temp, int backColor) {
		this.weatherImg = weatherImg;
		this.cityName = cityName;
		this.weather = weather;
		this.temp = temp;
		this.backColor = backColor;
	}

	public int getWeatherImg() {
		return weatherImg;
	}

	public void setWeatherImg(int weatherImg) {
		this.weatherImg = weatherImg;
	}

	public int getBackColor() {
		return backColor;
	}

	public void setBackColor(int backColor) {
		this.backColor = backColor;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getWeather() {
		return weather;
	}

	public void setWeather(String weather) {
		this.weather = weather;
	}

	public String getTemp() {
		return temp;
	}

	public void setTemp(String temp) {
		this.temp = temp;
	}
}
