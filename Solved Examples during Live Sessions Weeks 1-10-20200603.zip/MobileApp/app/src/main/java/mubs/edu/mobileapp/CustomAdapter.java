package mubs.edu.mobileapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {
	private Context gridContext;
	private Player[] players;

	public CustomAdapter(Context gridContext, Player[] players) {
		this.gridContext = gridContext;
		this.players = players;
	}

	@Override
	public int getCount() {
		return players.length;
	}

	@Override
	public Object getItem(int i) {
		return null;
	}

	@Override
	public long getItemId(int i) {
		return 0;
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		// i is the position
		// view is the Converted View
		Player p = players[i];

		if (view == null) {
			LayoutInflater inflater = LayoutInflater.from(gridContext);
			view = inflater.inflate(R.layout.activity_player, null);
		}

		ImageView playerImg = view.findViewById(R.id.item_gridview_img);
		TextView playerName = view.findViewById(R.id.item_gridview_playername);

		playerImg.setImageResource(p.getPlayerImg());
		playerName.setText(p.getPlayerName());

		return view;
	}
}
