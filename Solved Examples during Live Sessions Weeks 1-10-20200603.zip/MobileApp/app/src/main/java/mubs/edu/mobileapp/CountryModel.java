package mubs.edu.mobileapp;

public class CountryModel {
    private int CountryFlag;
    private String CountryName;
    private String PhoneCode;

    public CountryModel(int countryFlag, String countryName, String phoneCode) {
        CountryFlag = countryFlag;
        CountryName = countryName;
        PhoneCode = phoneCode;
    }

    public int getCountryFlag() {
        return CountryFlag;
    }

    public void setCountryFlag(int countryFlag) {
        CountryFlag = countryFlag;
    }

    public String getCountryName() {
        return CountryName;
    }

    public void setCountryName(String countryName) {
        CountryName = countryName;
    }

    public String getPhoneCode() {
        return PhoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        PhoneCode = phoneCode;
    }
}
