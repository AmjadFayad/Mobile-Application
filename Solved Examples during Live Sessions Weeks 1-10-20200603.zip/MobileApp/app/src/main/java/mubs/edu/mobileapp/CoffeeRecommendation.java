package mubs.edu.mobileapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class CoffeeRecommendation extends AppCompatActivity {
	Spinner spChoices;
	Button btnRecommand;
	TextView txtResult;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_coffee_recommendation);

		// Step 1: create a reference for each element in the xml file
		spChoices = findViewById(R.id.spchoices);
		btnRecommand = findViewById(R.id.btnRecommend);
		txtResult = findViewById(R.id.txtResult);

		// Step 1: create an event listener on Button click btnRecommend
		btnRecommand.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				txtResult.setText("Your choice is: " + spChoices.getSelectedItem().toString());
			}
		});
	}

	public static final int question1_ID = 101;
	public static final int question2_ID = 102;
	public static final int question3_ID = 103;
	public static final int Quit_ID = 104;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(1, question1_ID, 1, "Go to Question 1");
		menu.add(1, question2_ID, 2, "Go to Question 2");
		menu.add(1, question3_ID, 3, "Go to Question 3");
		menu.add(1, Quit_ID, 4, "Exit");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		switch (id) {
			case question1_ID:
				startActivity(new Intent(CoffeeRecommendation.this, Lab1Ex1.class));
				break;
			case question2_ID:
				startActivity(new Intent(CoffeeRecommendation.this, Lab1Ex2.class));
				break;
			case question3_ID:
				startActivity(new Intent(CoffeeRecommendation.this, Lab1Ex3.class));
				break;
			case Quit_ID:
				AlertDialog.Builder alert = new AlertDialog.Builder(this);
				alert.setMessage("Do you want to Exit");
				alert.setTitle("Alert msg");
				alert.setIcon(R.drawable.mubs);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						finish();
						startActivity(new Intent(CoffeeRecommendation.this, MainActivity.class));
					}
				});
				alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						Toast.makeText(getApplicationContext(), "You choose to stay on the same app", Toast.LENGTH_LONG).show();
					}
				});
				alert.show();
				break;
			default:
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
