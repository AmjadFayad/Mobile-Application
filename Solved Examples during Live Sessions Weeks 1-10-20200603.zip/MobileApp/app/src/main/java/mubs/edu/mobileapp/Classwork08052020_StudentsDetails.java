package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class Classwork08052020_StudentsDetails extends AppCompatActivity {
    ListView lstStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classwork08052020__students_details);
        lstStudents = findViewById(R.id.lstStudents);
        StudentDatabaseHelper helper = new StudentDatabaseHelper(this);
        ArrayList<HashMap<String, String>> data = helper.SelectAllStudents();
        String[] from =new String[]{"SID","SName","SGrade"};
        int[] to=new int[]{R.id.sampleSID,R.id.sampleSname,R.id.sampleSgrade};
        SimpleAdapter adapter = new SimpleAdapter(lstStudents.getContext(), data,
                R.layout.customstudentrow,from,to);
        lstStudents.setAdapter(adapter);
    }
}
