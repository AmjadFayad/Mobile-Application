package mubs.edu.mobileapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Classwork01052020_2 extends AppCompatActivity {
    EditText txtphonenumber,txtmsg;
    Button btnphonecall,btncamera,btnsendSMS;
    ImageView img_capture;
    public static int Request_Camera_Code=10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classwork01052020_2);
        txtphonenumber=findViewById(R.id.txtphonenumber);
        txtmsg=findViewById(R.id.txtMessage);
        btncamera=findViewById(R.id.btnTakepic);
        btnsendSMS=findViewById(R.id.btnSendSMS);
        btnphonecall=findViewById(R.id.btnPhoneCall);
        img_capture=findViewById(R.id.img_capture);
        btnphonecall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phonenb=txtphonenumber.getText().toString();
                Uri uri_phone=Uri.parse("tel:"+phonenb);
                Intent intent =new Intent(Intent.ACTION_DIAL,uri_phone);
                startActivity(intent);
            }
        });
       /* btnsendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("smsto:"));
                intent.putExtra("address",txtphonenumber.getText().toString());
                intent.putExtra("sms_body",txtmsg.getText().toString());
                intent.setType("vnd.android-dir/mms-sms");
                startActivity(intent);
            }
        });*/
        btnsendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent=new Intent(Intent.ACTION_VIEW);
                SmsManager smsManager=SmsManager.getDefault();
                smsManager.sendTextMessage(txtphonenumber.getText().toString(),"78885885",
                        txtmsg.getText().toString(),null,null);
               // startActivity(intent);
            }
        });

        btncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraintent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraintent,Request_Camera_Code);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent d) {
        if (resultCode==RESULT_OK && requestCode==Request_Camera_Code){
           Bitmap img= (Bitmap) d.getExtras().get("data");
           img_capture.setImageBitmap(img);
        }
    }
}
