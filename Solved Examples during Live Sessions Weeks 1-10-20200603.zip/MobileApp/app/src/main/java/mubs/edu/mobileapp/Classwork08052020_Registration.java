package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import mubs.edu.mobileapp.ui.login.Classwork08052020_Login;

public class Classwork08052020_Registration extends AppCompatActivity {
    EditText txtID,txtSname,txtSpass,txtSconfPass,txtEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classwork08052020__registration);
        txtID=findViewById(R.id.txtSID);
        txtSname=findViewById(R.id.txtSname);
        txtSpass=findViewById(R.id.txtSPass);
        txtSconfPass=findViewById(R.id.txtSConfPass);
        txtEmail=findViewById(R.id.txtSEmail);
    }

    public void Register(View view) {
        int sid= Integer.parseInt(txtID.getText().toString());
        String sname=txtSname.getText().toString();
        String Email=txtEmail.getText().toString();
        String pass=txtSpass.getText().toString();
        String confpass=txtSconfPass.getText().toString();
        if(!pass.equals(confpass)){
            Toast.makeText(this, "Password not match !!!", Toast.LENGTH_SHORT).show();
            return;
        }
        StudentDatabaseHelper helper=new StudentDatabaseHelper(this);
        if(helper.InsertNewStudent(sid,sname,Email,pass,0)) {
            Toast.makeText(this, "New Record inserted", Toast.LENGTH_SHORT).show();
            Intent i=new Intent(Classwork08052020_Registration.this,
                    Classwork08052020_Login.class);
            startActivity(i);
        }
        else
            Toast.makeText(this, "Error during insertion", Toast.LENGTH_SHORT).show();
    }
}
