package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Lab2EX1 extends AppCompatActivity {
	Button[][] buttons = new Button[3][3];
	TextView txtPlayer1, txtPlayer2, txtScorep1, txtScorep2;
	Button btnReset;
	int turn_player = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lab2_ex1);

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				String buttonID = "btn_" + i + j;
				int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
				buttons[i][j] = findViewById(resID);
				buttons[i][j].setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						buttons_Clicked(v);
					}
				});
			}
		}
		txtPlayer1 = findViewById(R.id.txtPlayer1);
		txtPlayer2 = findViewById(R.id.txtPlayer2);
		txtScorep1 = findViewById(R.id.txtScorep1);
		txtScorep2 = findViewById(R.id.txtScorep2);
		btnReset = findViewById(R.id.btnResetGame);

		btnReset.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				txtScorep1.setText("0");
				txtScorep2.setText("0");
				ClearButton();
			}
		});
	}

	private Boolean isBoardFull() {
		for (int i = 0; i < buttons.length; i++) {
			for (int j = 0; j < buttons[i].length; j++) {
				if (buttons[i][j].getText().equals("-")) {
					return false;
				}
			}
		}
		return true;
	}

	private void ClearButton() {
		for (int i = 0; i < buttons.length; i++) {
			for (int j = 0; j < buttons[i].length; j++) {
				buttons[i][j].setText("-");
			}
		}
	}

	private Boolean checkRowsForWin() {
		for (int row = 0; row < 3; row++) {
			if (buttons[row][0].getText().equals(buttons[row][1].getText())
					&& buttons[row][0].getText().equals(buttons[row][2].getText())
					&& !buttons[row][0].getText().equals("-")) {
				return true;
			}
		}
		return false;
	}

	private Boolean checkColumnForWin() {
		for (int col = 0; col < 3; col++) {
			if (buttons[0][col].getText().equals(buttons[1][col].getText())
					&& buttons[0][col].getText().equals(buttons[2][col].getText())
					&& !buttons[0][col].getText().equals("-")) {
				return true;
			}
		}
		return false;
	}

	private Boolean checkDiagonalForWin() {
		if (buttons[0][0].getText().equals(buttons[1][1].getText())
				&& buttons[0][0].getText().equals(buttons[2][2].getText())
				&& !buttons[0][0].getText().equals("-")) {
			return true;
		}
		if (buttons[2][0].getText().equals(buttons[1][1].getText())
				&& buttons[0][0].getText().equals(buttons[0][2].getText())
				&& !buttons[2][0].getText().equals("-")) {
			return true;
		}
		return false;
	}

	private Boolean checkForWin() {
		if (checkColumnForWin() || checkRowsForWin() || checkDiagonalForWin()) {
			return true;
		} else {
			return false;
		}
	}

	private void buttons_Clicked(View view) {
		Button btn = (Button) view;
		if (btn.getText().toString().equals("-")) {
			if (turn_player == 1)
				btn.setText("X");
			else
				btn.setText("O");
		}
		if (checkForWin()) {
			if (turn_player == 1) {
				Toast.makeText(this, "Player 1 Wins", Toast.LENGTH_LONG).show();
				int oldScore = Integer.parseInt(txtScorep1.getText().toString());
				txtScorep1.setText((oldScore + 1) + "");
			} else {
				Toast.makeText(this, "Player 2 Wins", Toast.LENGTH_LONG).show();
				int oldScore = Integer.parseInt(txtScorep2.getText().toString());
				txtScorep2.setText((oldScore + 1) + "");
			}
			ClearButton();
		} else {
			if (turn_player == 1) {
				txtPlayer2.setTextColor(Color.RED);
				txtPlayer1.setTextColor(Color.BLACK);
				turn_player = 2;
			} else {
				txtPlayer1.setTextColor(Color.RED);
				txtPlayer2.setTextColor(Color.BLACK);
				turn_player = 1;
			}
			if (isBoardFull()) {
				Toast.makeText(this, "No Winner", Toast.LENGTH_LONG).show();
				ClearButton();
			}
		}
	}
}
