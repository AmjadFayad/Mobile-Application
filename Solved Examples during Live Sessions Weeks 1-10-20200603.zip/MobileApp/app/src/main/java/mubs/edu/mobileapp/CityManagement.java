package mubs.edu.mobileapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.GridView;

public class CityManagement extends AppCompatActivity {
	GridView gridView;
	CityManagementModel[] city = new CityManagementModel[4];

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_city_management);

		ActionBar actionBar = getSupportActionBar();
		actionBar.hide();

		gridView = findViewById(R.id.city_grid_view);

		city[0] = new CityManagementModel(R.drawable.sunny, "New York", "Sunny", "12", Color.RED);
		city[1] = new CityManagementModel(R.drawable.hazysunshine, "Mumbai", "Hazy Sunshine", "25", Color.BLUE);
		city[2] = new CityManagementModel(R.drawable.rainy, "Sydney", "Rainy", "12", Color.YELLOW);
		city[3] = new CityManagementModel(R.drawable.hazysunshine, "Tokyo", "Hazy Sunshine", "25", Color.BLACK);

		CityManagementAdapter adapter = new CityManagementAdapter(gridView.getContext(), city);
		gridView.setAdapter(adapter);
	}
}
