package mubs.edu.mobileapp;

public class Player {
	private int playerImg;
	private String playerName;

	public Player(int playerImg, String playerName) {
		this.playerImg = playerImg;
		this.playerName = playerName;
	}

	public int getPlayerImg() {
		return playerImg;
	}

	public void setPlayerImg(int playerImg) {
		this.playerImg = playerImg;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
}
