package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Lab2Ex2 extends AppCompatActivity {
	String[] plates = new String[]{"Tabouli-5000", "Homous-3000", "Batata-7000", "Machawi-25000", "Samak-40000", "Tawoa-20000"};
	CheckBox[] checkBoxes = new CheckBox[6];
	TextView TotalPrice;
	RatingBar rbrest;
	ListView lstPlates;
	Button btnInvoice;
	RadioButton rbYes;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lab2_ex2);

		for (int i = 0; i < checkBoxes.length; i++) {
			String ref_name = "chk_" + (i + 1);
			int ref_id = getResources().getIdentifier(ref_name, "id", getPackageName());
			checkBoxes[i] = findViewById(ref_id);
			checkBoxes[i].setText(plates[i]);
		}

		TotalPrice = findViewById(R.id.ltTotal);
		rbrest = findViewById(R.id.rbRestaurant);
		lstPlates = findViewById(R.id.lstPlates);
		btnInvoice = findViewById(R.id.btnInvoice);
		rbYes = findViewById(R.id.rbYes);

		TotalPrice.setVisibility(View.INVISIBLE);
		rbrest.setVisibility(View.INVISIBLE);

		btnInvoice.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				btnInvoiceClick();
			}
		});

		rbrest.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
				Toast.makeText(Lab2Ex2.this, "Rate: " + rating, Toast.LENGTH_LONG).show();
			}
		});

	}

	private void btnInvoiceClick() {
		ArrayList<String> data = new ArrayList<>();
		double price = 0.;

		for (CheckBox chk : checkBoxes) {
			if (chk.isChecked()) {
				data.add(chk.getText().toString());
				price += Double.parseDouble(chk.getText().toString().split("-")[1]);
			}
		}

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(lstPlates.getContext(), android.R.layout.simple_list_item_1, data);
		lstPlates.setAdapter(adapter);
		if (rbYes.isChecked()) {
			price *= 1.11;
		}

		TotalPrice.setText(String.format("Total: %.2f", price));
		TotalPrice.setVisibility(View.VISIBLE);
		rbrest.setVisibility(View.VISIBLE);
	}
}
