package mubs.edu.mobileapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Lab1Ex3 extends AppCompatActivity {
	private static final String TAG = "Lab1Ex3";
	private int year;

	EditText weightID, heightID, etdob;
	RadioButton rbmale, rbfemale;
	DatePickerDialog.OnDateSetListener mDateSetListener;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lab1_ex3);

		weightID = findViewById(R.id.weightID);
		heightID = findViewById(R.id.heightID);
		etdob = findViewById(R.id.etdob);
		rbmale = findViewById(R.id.rbmale);
		rbfemale = findViewById(R.id.rbfemale);

		etdob.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Calendar cal = Calendar.getInstance();
				int day = cal.get(Calendar.DAY_OF_MONTH);
				int month = cal.get(Calendar.MONTH);
				year = cal.get(Calendar.YEAR);

				DatePickerDialog dialog = new DatePickerDialog(
						Lab1Ex3.this,
						android.R.style.Theme_Holo_Dialog_MinWidth,
						mDateSetListener,
						year, month, day);
				dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
				dialog.show();
			}
		});
		mDateSetListener = new DatePickerDialog.OnDateSetListener() {
			@Override
			public void onDateSet(DatePicker datePicker, int year, int month, int day) {
				month = month + 1;
				Log.d(TAG, "onDateSet: mm/dd/yyyy" + month + "/" + day + "/" + year);
				String date = day + "/" + month + "/" + year;
				etdob.setText(date);
			}
		};
	}

	public void CalculateHowFitOnclick(View view) {
		try {
			String bmiCase = "Your BMI is: ";

			double weight = Double.parseDouble(weightID.getText().toString());
			double height = Double.parseDouble(heightID.getText().toString());

			double bmi = weight / Math.pow(height * 0.01, 2);

			if (bmi >= 18.5 && bmi <= 24.9) {
				bmiCase = "Normal weight: BMI = ";
			} else if (bmi >= 25 && bmi <= 29.9) {
				bmiCase = "Overweight: BMI = ";
			} else if (bmi >= 30) {
				bmiCase = "Obese: BMI = ";
			}

			Toast.makeText(this, bmiCase + Math.round(bmi), Toast.LENGTH_SHORT).show();
		} catch (Exception ex) {
			weightID.setText("");
			heightID.setText("");
			Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
		}
	}

	public void CalculateAmounttoEat(View view) {
		try {
			double dci = 0;
			double weight = Double.parseDouble(weightID.getText().toString());
			double height = Double.parseDouble(heightID.getText().toString());

			String strCurrentYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
			int currentYear = Integer.parseInt(strCurrentYear);
			int age = currentYear - year;

			if (weight > 0 && height > 0 && year > 0) {
				if (rbmale.isChecked()) {
					dci = 66.5 + (13.8 * weight) + (5 * height) - (6.75 * age);
				} else if (rbfemale.isChecked()) {
					if (age <= 24) {
						dci = 655 + (9.6 * weight) + (1.8 * height) - (4.7 * age);
					} else {
						dci = 455 + (9.6 * weight) + (1.8 * height) - (4.7 * age);
					}
				}

				Intent intent = new Intent(this, Result.class);
				intent.putExtra("keyDCI", dci);
				startActivity(intent);
			} else {
				weightID.setText("");
				heightID.setText("");
				etdob.setText("");
				Toast.makeText(this, "Input can't be Zero", Toast.LENGTH_SHORT).show();
			}
		} catch (Exception ex) {
			weightID.setText("");
			heightID.setText("");
			Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
		}
	}

	// Option Menu
	public static final int question1_ID = 101;
	public static final int question2_ID = 102;
	public static final int coffee_ID = 103;
	public static final int Quit_ID = 104;


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(1, question1_ID, 1, "Go to Question 1");
		menu.add(1, question2_ID, 2, "Go to Question 2");
		menu.add(1, coffee_ID, 3, "Coffee");
		menu.add(1, Quit_ID, 4, "Exit");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		switch (id) {
			case question1_ID:
				startActivity(new Intent(Lab1Ex3.this, Lab1Ex1.class));
				break;
			case question2_ID:
				startActivity(new Intent(Lab1Ex3.this, Lab1Ex2.class));
				break;
			case coffee_ID:
				startActivity(new Intent(Lab1Ex3.this, CoffeeRecommendation.class));
				break;
			case Quit_ID:
				AlertDialog.Builder alert = new AlertDialog.Builder(this);
				alert.setMessage("Do you want to Exit");
				alert.setTitle("Alert msg");
				alert.setIcon(R.drawable.mubs);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						finish();
						startActivity(new Intent(Lab1Ex3.this, MainActivity.class));
					}
				});
				alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						Toast.makeText(getApplicationContext(), "You choose to stay on the same app", Toast.LENGTH_LONG).show();
					}
				});
				alert.show();
				break;
			default:
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
