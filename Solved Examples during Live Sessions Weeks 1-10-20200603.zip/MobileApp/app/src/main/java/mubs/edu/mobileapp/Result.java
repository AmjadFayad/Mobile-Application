package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Result extends AppCompatActivity {
	TextView resulttext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result);

		resulttext = findViewById(R.id.resulttext);

		Intent incomingIntent = getIntent();
		double incomingDCI = incomingIntent.getDoubleExtra("keyDCI", 0);

		resulttext.setText(String.format("You nee to eat %.2f calories per day", incomingDCI));
	}
}
