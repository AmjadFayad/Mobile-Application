package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class Classwork22042020 extends AppCompatActivity {
    ListView lstcountries;
    int[] images=new int[]{R.drawable.lebanon,R.drawable.france,R.drawable.lebanon,
            R.drawable.lebanon,R.drawable.lebanon};
    String[] countryname=new String[]{"Lebanon","France","USA","UK","Poland"};
    String[] phonecode=new String[]{"+961","+33","+1","+44","+48"};
    ArrayList<CountryModel> data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classwork22042020);
        lstcountries=findViewById(R.id.lstCountries_2);
        data=new ArrayList<>();
        for (int i=0;i<images.length;i++){
            data.add(new CountryModel(images[i],countryname[i],phonecode[i]));
        }
        CountryAdapter adapter=new CountryAdapter(this,data);
        lstcountries.setAdapter(adapter);
        lstcountries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
              CountryModel selectedCountry= data.get(position);
              Intent intent=new Intent(getApplicationContext(),Classwork01052020_1.class);
              intent.putExtra("CountryFlag",selectedCountry.getCountryFlag());
              intent.putExtra("CountryName",selectedCountry.getCountryName());
              intent.putExtra("PhoneCode",selectedCountry.getPhoneCode());
              startActivity(intent);
            }
        });
    }
}
