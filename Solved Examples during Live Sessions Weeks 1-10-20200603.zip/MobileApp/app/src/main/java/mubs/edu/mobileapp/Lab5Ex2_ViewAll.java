package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class Lab5Ex2_ViewAll extends AppCompatActivity {
    ListView lstPlaces;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab5_ex2__view_all);
        Lab5Ex2DatabaseHelper helper=new Lab5Ex2DatabaseHelper(this);
        lstPlaces=findViewById(R.id.lstPlaces);
        ArrayList<HashMap<String,String>> data=helper.getAllPlaces();

        String[] from=new String[]{"PlaceID","PlaceName","Country"};
        int[] to=new int[]{R.id.sampleplacerow_id,R.id.sampleplacerow_placename,
                R.id.sampleplacerow_country};
        SimpleAdapter adapter=new SimpleAdapter(lstPlaces.getContext(),data,
                R.layout.sampleplacerow,from,to);
        lstPlaces.setAdapter(adapter);
    }
}
