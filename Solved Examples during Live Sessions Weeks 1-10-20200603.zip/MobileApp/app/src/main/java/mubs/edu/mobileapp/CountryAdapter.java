package mubs.edu.mobileapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public class CountryAdapter extends ArrayAdapter<CountryModel> {
    private Context ctx;
    private ArrayList<CountryModel> CountryList;

    public CountryAdapter(Context context, ArrayList<CountryModel> data) {
        super(context,0,data);
        this.ctx = context;
        CountryList = data;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        CountryModel country_element= CountryList.get(position);
        if (convertView==null)
            convertView= LayoutInflater.from(this.ctx).inflate(R.layout.country_simple_row,null);
        ImageView flagimg=convertView.findViewById(R.id.sample_flagimg);
        TextView txtcountryName=convertView.findViewById(R.id.sample_countryname);
        TextView txtphonecode=convertView.findViewById(R.id.sample_phonecode);
        flagimg.setImageResource(country_element.getCountryFlag());
        txtcountryName.setText(country_element.getCountryName());
        txtphonecode.setText(country_element.getPhoneCode());
        return convertView;
    }

    @Override
    public int getCount() {
        return this.CountryList.size();
    }
}
