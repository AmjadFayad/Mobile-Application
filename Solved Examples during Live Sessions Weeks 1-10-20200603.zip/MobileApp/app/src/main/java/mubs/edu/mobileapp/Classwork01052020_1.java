package mubs.edu.mobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Classwork01052020_1 extends AppCompatActivity {
    ImageView imgFlag;
    TextView txtCountryName,txtPhoneCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classwork01052020_1);
        //get extra infomation received from the intent of the activity "Classwork22042020"
        Bundle b=getIntent().getExtras();
        int refImage=b.getInt("CountryFlag");
        String Countryname=b.getString("CountryName");
        String Phonecode=b.getString("PhoneCode");

        //create a reference on each control of the layout "classwork01052020_1_activuty.xml"
        txtCountryName=findViewById(R.id.countryName);
        txtPhoneCode=findViewById(R.id.phoneCode);
        imgFlag=findViewById(R.id.img_Flag);

        //put received infomation from the intent in the layout controls
        imgFlag.setImageResource(refImage);
        txtPhoneCode.setText(Phonecode);
        txtCountryName.setText(Countryname);
    }
}
