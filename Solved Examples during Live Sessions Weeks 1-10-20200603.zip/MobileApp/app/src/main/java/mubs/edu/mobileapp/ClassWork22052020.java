package mubs.edu.mobileapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.internal.NavigationMenu;
import com.google.android.material.internal.NavigationMenuView;

public class ClassWork22052020 extends AppCompatActivity {
    BottomNavigationView navigation;
    FrameLayout contentlayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_work22052020);
        navigation=findViewById(R.id.btmNavigationView);
        contentlayout=findViewById(R.id.frmLayout);
        //Initial fragment will be displayed at the running of the activity
        getSupportFragmentManager().beginTransaction().add(R.id.frmLayout,new HomeFragment()).commit();

        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int selectedoptionID=menuItem.getItemId();
                Fragment fragment=null;
                switch (selectedoptionID){
                    case R.id.bottom_nav_home:
                        fragment=new HomeFragment();
                        break;
                    case R.id.bottom_nav_chats:
                        fragment=new ChatsFragment();
                        break;
                    case R.id.bottom_nav_settings:
                        fragment=new SettingsFragment();
                        break;
                    case R.id.bottom_nav_mubs:
                        fragment=new MUBSFragment();
                        break;
                }
               FragmentTransaction transaction= getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frmLayout,fragment);
                transaction.commit();
                return true;
            }
        });
    }
}
