package mubs.edu.mobileapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.HashMap;

public class Lab1Ex2 extends AppCompatActivity {
	EditText ETvalue1, ETvalue2;
	Spinner SPvalue1, SPvalue2;
	Button btnCurrencyConvert;
	HashMap<String, Double> map = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lab1_ex2);

		ETvalue1 = findViewById(R.id.ETvalue1);
		ETvalue2 = findViewById(R.id.ETvalue2);

		ETvalue2.setEnabled(false);

		SPvalue1 = findViewById(R.id.SPvalue1);
		SPvalue2 = findViewById(R.id.SPvalue2);

		btnCurrencyConvert = findViewById(R.id.btnCurrencyConvert);

		btnCurrencyConvert.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				ConvertMoney_Click(view);
			}
		});

		map = new HashMap<String, Double>();
		map.put("EURO/USD", 1.12);
		map.put("EURO/LBP", 3136.0);

		map.put("USD/EURO", 0.892);
		map.put("USD/LBP", 2800.0);

		map.put("LBP/EURO", 0.000318);
		map.put("LBP/USD", 0.000357);
	}

	public void ConvertMoney_Click(View v) {
		try {
			double etV1 = Double.parseDouble(ETvalue1.getText().toString());

			String spV1 = SPvalue1.getSelectedItem().toString();
			String spV2 = SPvalue2.getSelectedItem().toString();


			if (spV1.equals(spV2)) {
				ETvalue2.setText(String.valueOf(etV1));
			} else {
				// Solution 1
				String key = spV1 + "/" + spV2;
				ETvalue2.setText(String.format("%.2f", etV1 * map.get(key)));
			}

			// Solution 2
//            double result;
//            if (spV1.equals(spV2)) {
//                ETvalue2.setText(String.valueOf(etV1));
//            } else {
//                // EURO
//                if (spV1.equals("EURO") && spV2.equals("USD")) {
//                    result = etV1 * 1.08;
//                    ETvalue2.setText(String.valueOf(result));
//                } else if (spV1.equals("EURO") && spV2.equals("LBP")) {
//                    result = etV1 * 1632;
//                    ETvalue2.setText(String.valueOf(result));
//                }
//                // USD
//                if (spV1.equals("USD") && spV2.equals("EURO")) {
//                    result = etV1 / 1.08;
//                    ETvalue2.setText(String.valueOf(result));
//                } else if (spV1.equals("USD") && spV2.equals("LBP")) {
//                    result = etV1 * 1507;
//                    ETvalue2.setText(String.valueOf(result));
//                }
//                // LBP
//                if (spV1.equals("LBP") && spV2.equals("EURO")) {
//                    result = etV1 / 1632;
//                    ETvalue2.setText(String.valueOf(result));
//                } else if (spV1.equals("LBP") && spV2.equals("USD")) {
//                    result = etV1 / 1507;
//                    ETvalue2.setText(String.valueOf(result));
//                }
//            }

		} catch (Exception ex) {
			ETvalue1.setText("");
			ETvalue2.setText("");
			Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
		}
	}

	public static final int question1_ID = 101;
	public static final int question3_ID = 102;
	public static final int coffee_ID = 103;
	public static final int Quit_ID = 104;


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(1, question1_ID, 1, "Go to Question 1");
		menu.add(1, question3_ID, 2, "Go to Question 3");
		menu.add(1, coffee_ID, 3, "Coffee");
		menu.add(1, Quit_ID, 4, "Exit");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		switch (id) {
			case question1_ID:
				startActivity(new Intent(Lab1Ex2.this, Lab1Ex1.class));
				break;
			case question3_ID:
				startActivity(new Intent(Lab1Ex2.this, Lab1Ex3.class));
				break;
			case coffee_ID:
				startActivity(new Intent(Lab1Ex2.this, CoffeeRecommendation.class));
				break;
			case Quit_ID:
				AlertDialog.Builder alert = new AlertDialog.Builder(this);
				alert.setMessage("Do you want to Exit");
				alert.setTitle("Alert msg");
				alert.setIcon(R.drawable.mubs);
				alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						finish();
						startActivity(new Intent(Lab1Ex2.this, MainActivity.class));
					}
				});
				alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						Toast.makeText(getApplicationContext(), "You choose to stay on the same app", Toast.LENGTH_LONG).show();
					}
				});
				alert.show();
				break;
			default:
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
